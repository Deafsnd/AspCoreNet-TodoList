using AspNetCoreTodo.Services;
using AspNetCoreTodo.Models;

namespace AspNetCoreTodo.Models
{
    public class TodoViewModel
    {
        public TodoItem[]? Items { get; set; }
    }
}